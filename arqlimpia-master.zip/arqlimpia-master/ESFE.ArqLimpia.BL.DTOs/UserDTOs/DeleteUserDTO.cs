﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ESFE.ArqLimpia.BL.DTOs.UserDTOs
{
    public class DeleteUserDTO
    {
        public int Id { get; set; }
    }
}
